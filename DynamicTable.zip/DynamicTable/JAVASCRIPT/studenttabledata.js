
var Tabletag = document.createElement("table");
var bodyAddress = document.getElementsByTagName("body");
bodyAddress[0].appendChild(Tabletag);
Tabletag.setAttribute("class","MyTable");

var AllFunctionmap={
    StudentData:[
        {
            
            "Name":"Rahul",
            "Age":18,
            "Marks":95,
            "Course":"CSE"
        },
        {
            
            "Name":"Raj",
            "Age":19,
            "Marks":85,
            "Course":"IT"
        },
        {
            
            "Name":"Alex",
            "Age":18,
            "Marks":96,
            "Course":"DS"
        },
        {
            
            "Name":"Venkat",
            "Age":19,
            "Marks":100,
            "Course":"AIML"
        }
    ],
    createtable:function(){
        let row=document.createElement("tr");
        var TableTagAdrssInside = document.getElementsByClassName("MyTable");
        TableTagAdrssInside[0].appendChild(row);
     
        let col2=document.createElement("th");
        let col3=document.createElement("th");
        let col4=document.createElement("th");
        let col5=document.createElement("th");
        let col6=document.createElement("th");
    
        row.appendChild(col2);
        row.appendChild(col3);
        row.appendChild(col4);
        row.appendChild(col5);
        row.appendChild(col6);
 
        col2.innerHTML="Name";
        col3.innerHTML="Age";
        col4.innerHTML="Marks";
        col5.innerHTML="Course";
        col6.innerHTML="Actions";
        var Index=1;
        for(var i =0;i<this.StudentData.length;i++)
            {
                let x=document.createElement("tr");
                x.setAttribute("id",Index);
                
   
                let y2=document.createElement("td");
                let y3=document.createElement("td");
                let y4=document.createElement("td");
                let y5=document.createElement("td");
                let y6=document.createElement("td");
                TableTagAdrssInside[0].appendChild(x);

                x.appendChild(y2);
                x.appendChild(y3);
                x.appendChild(y4);
                x.appendChild(y5);
                x.appendChild(y6);
                y2.setAttribute("contenteditable","true");
                y3.setAttribute("contenteditable","true");
                y4.setAttribute("contenteditable","true");
                y5.setAttribute("contenteditable","true");
       
                y2.innerHTML=this.StudentData[i]["Name"];
                y3.innerHTML=this.StudentData[i]["Age"];
                y4.innerHTML=this.StudentData[i]["Marks"];
                y5.innerHTML=this.StudentData[i]["Course"]; 
                let delbtn=document.createElement("button");
                delbtn.innerHTML="";
                y6.appendChild(delbtn);
                delbtn.setAttribute("class","DeleteButton");
                delbtn.setAttribute("onclick",`AllFunctionmap.DeleteRow(${Index})`);
                Index+=1;
            }
        
    },
    AddToTable:function(){
        var x={
            "Name":window.prompt("Enter The Name"),
            "Age":window.prompt("Enter The Age"),
            "Marks":window.prompt("Enter The Marks"),
            "Course":window.prompt("Enter The Course")
        }
        var Tabletag = document.getElementsByClassName("MyTable");
        var Index=this.StudentData.length+1;
        this.StudentData.push(x);
        let row=document.createElement("tr");
        row.setAttribute("id",Index);

        let y2=document.createElement("td");
        let y3=document.createElement("td");
        let y4=document.createElement("td");
        let y5=document.createElement("td");
        let y6=document.createElement("td");
        Tabletag[0].appendChild(row);

        row.appendChild(y2);
        row.appendChild(y3);
        row.appendChild(y4);
        row.appendChild(y5);
        row.appendChild(y6);
        y2.setAttribute("contenteditable","true");
        y3.setAttribute("contenteditable","true");
        y4.setAttribute("contenteditable","true");
        y5.setAttribute("contenteditable","true");

        y2.innerHTML=x["Name"];
        y3.innerHTML=x["Age"];
        y4.innerHTML=x["Marks"];
        y5.innerHTML=x["Course"];
        let delbtn=document.createElement("button");
        delbtn.innerHTML="";
        y6.appendChild(delbtn);
        delbtn.setAttribute("class","DeleteButton");
        delbtn.setAttribute("onclick",`AllFunctionmap.DeleteRow(${Index})`);
    },
    cnt : 0,
    DisplayandAddintoTable:function(){
        this.cnt+=1;
        if(this.cnt==1){
            this.createtable();
        }
        else{
            this.AddToTable();
        }
    },
    DeleteRow:function(Id){
        var TableRow=document.getElementById(Id);
        var TableTagAdrss=document.getElementsByClassName("MyTable");
        TableTagAdrss[0].removeChild(TableRow);
    }
}



